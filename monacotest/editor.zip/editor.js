// Create the Editor Instance
require(['vs/editor/editor.main'], function () {
    document.editor = monaco.editor.create(document.getElementById('container'), {
        value: '',
        language: 'typescript',
        scrollbar: {
            horizontal: 'hidden',
            vertical: 'hidden'
        }
    });
    // Bind content
    document.editor.onDidChangeModelContent(function () {
        window.external.onValueChanged(document.editor.getValue());
    });
    // Handle layout, fill the control and resize
    document.editor.layout({ width: window.external.getWidth(), height: window.external.getHeight() });
    window.onresize = function () {
        document.editor.layout({ width: window.external.getWidth(), height: window.external.getHeight() });
    };
    monaco.languages.registerCompletionItemProvider('csharp', new CsharpCompletionProvider());
});
// Functions exposed to the CLR
function editorGetValue() {
    return document.editor.getValue();
}
function editorSetValue(value) {
    document.editor.setValue(value);
}
function editorGetLang() {
    return "";
}
function editorSetLang(lang) {
    monaco.editor.setModelLanguage(document.editor.getModel(), lang);
}
// Csharp language services...
var CsharpCompletionProvider = /** @class */ (function () {
    function CsharpCompletionProvider() {
    }
    CsharpCompletionProvider.prototype.provideCompletionItems = function (model, position, token) {
        return [{ label: "test" }];
    };
    CsharpCompletionProvider.prototype.resolveCompletionItem = function (item, token) {
        return { label: "test" };
    };
    return CsharpCompletionProvider;
}());
//# sourceMappingURL=editor.js.map